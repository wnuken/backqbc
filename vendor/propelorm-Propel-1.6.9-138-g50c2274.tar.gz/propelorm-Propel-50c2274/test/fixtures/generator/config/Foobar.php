<?php

/**
 * Fake class
 */
class Foobar
{
}
