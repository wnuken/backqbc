
<?php echo $comment ?>
<?php echo $functionStatement ?>

    return $this->getCurrentTranslation()->get<?php echo $columnPhpName ?>(<?php echo $params ?>);
}
