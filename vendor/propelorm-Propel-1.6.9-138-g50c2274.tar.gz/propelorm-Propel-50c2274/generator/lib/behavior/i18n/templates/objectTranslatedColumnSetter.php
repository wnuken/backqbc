
<?php echo $comment ?>
<?php echo $functionStatement ?>
    $this->getCurrentTranslation()->set<?php echo $columnPhpName ?>(<?php echo $params ?>);

    return $this;
}
