$this->currentLocale = '<?php echo $defaultLocale ?>';
$this->currentTranslations = null;
